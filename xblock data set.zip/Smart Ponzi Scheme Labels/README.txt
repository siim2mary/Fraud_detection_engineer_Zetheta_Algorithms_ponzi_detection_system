﻿1.English Version
2.中文版

============================================
Smart ponzi scheme labels
============================================
By InPlusLab, Sun Yat-sen University


================== References ==================

• Website
	http://xblock.pro/ethereum/

• Cite
    W. Chen, Z. Zheng, J. Cui, E. Ngai, P. Zheng, and Y. Zhou, “Detecting Ponzi Schemes on Ethereum: Towards Healthier Blockchain Technology,” pp. 1409–1418, 2018, doi: 10.1145/3178876.3186046.


================== Change Log =================

• Version 1.0, released on 22/11/2018


=================== Source ====================

The user transaction dataset is crawed from a node in Ethereum network. The labels of contracts are labeled manually. 


================ File Information =================

• Description
	The task of smart Ponzi scheme detection is to predict whether a given smart contract is a ponzi scheme. 
	To train the classification model, we manually check more than 3,000 smart contracts by reading their source codes. 
	The user transcation data are also used to train the model.

• Contents
	- Ponzi Scheme Labels
		Labels of whether a smart contract is a ponzi scheme.
		Size: 170KB


———————————— Ponzi Scheme Labels ———————————— 

• Ponzi_label.csv 

	
	- Row:
		Each row represents an smart contract from Ethereum
  
	- Column:
		1.Contract :  The address of the contract
		2.Ponzi	   :  Whether the contract is a ponzi scheme. (1 if yes)
		Sum: 2 columns

		
* Notes * 

===================Contact====================

Please contact Dan Lin (lind8@mail2.sysu.edu.cn) for any questions about the dataset.



============================================
智能合约庞氏骗局标签
============================================
By InPlusLab, 中山大学


==================== 参考 =====================

• 相关网站
	http://xblock.pro/ethereum/

• 引用
	W. Chen, Z. Zheng, J. Cui, E. Ngai, P. Zheng, and Y. Zhou, “Detecting Ponzi Schemes on Ethereum: Towards Healthier Blockchain Technology,” pp. 1409–1418, 2018, doi: 10.1145/3178876.3186046.


=================== 变更日志 ====================

• 版本 1.0, 发布于 22/11/2018


=================== 数据来源 ====================

其中以太坊用户交易数据来自以太坊网络中的一个全节点。庞氏骗局标签数据由人工检查得来。


=================== 文件信息 ====================

• 描述
	智能合约庞氏骗局检测的目标就是对于指定的合约，预测其是否是庞氏骗局。
	为了训练一个分类模型，我们人工检查了超过3000个合约的源码，为其贴上是否为庞氏骗局的标签。
	同时，我们在训练中也将用户的交易数据作为特征输入模型。

• 内容
	- 庞氏骗局标签
		某个智能合约是否是旁氏骗局的标签。
		大小: 170KB



———————————— 庞氏骗局标签 ———————————— 

• Ponzi_label.csv 

	- 行:
		每一行代表了一个智能合约
  
	- 列:
		1.Contract :  智能合约的地址。
		2.Ponzi    :  该合约是否为庞氏骗局。 （若是则为1）
		总和: 2 列

	


* 注释 * 


==================== 联系 =====================

若对数据集有任何问题请联系 林丹 (lind8@mail2.sysu.edu.cn)。